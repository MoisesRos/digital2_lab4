

#include <avr/io.h>
#include <avr/interrupt.h>
#include "TWI_Slave/TWI_Slave.h"
#define F_CPU 16000000UL

#define SLAVE_ADDRESS 0x10

volatile uint8_t counter = 0;

void updateLEDs(void) {
    // Actualiza cada LED individualmente seg�n el bit correspondiente del contador
    if (counter & 0x01)
        PORTD |= (1 << PD0);
    else
        PORTD &= ~(1 << PD0);
    
    if (counter & 0x02)
        PORTD |= (1 << PD1);
    else
        PORTD &= ~(1 << PD1);
    
    if (counter & 0x04)
        PORTD |= (1 << PD2);
    else
        PORTD &= ~(1 << PD2);
    
    if (counter & 0x08)
        PORTD |= (1 << PD3);
    else
        PORTD &= ~(1 << PD3);
}

ISR(PCINT1_vect) {
    uint8_t pinc = PINC;
    // Bot�n de incremento en PC0 (activo en bajo)
    if (!(pinc & (1 << PC0))) {
        if (counter < 15)
            counter++;
    }
    // Bot�n de decremento en PC1 (activo en bajo)
    if (!(pinc & (1 << PC1))) {
        if (counter > 0)
            counter--;
    }
    updateLEDs();
}

int main(void) {
    // Desactiva el USART para liberar PD0 (RX) y PD1 (TX)
    UCSR0B = 0;
    
	

    // Configura PD0, PD1, PD2 y PD3 como salidas para los LEDs
    DDRD |= (1 << PD0) | (1 << PD1) | (1 << PD2) | (1 << PD3);
    PORTD &= ~((1 << PD0) | (1 << PD1) | (1 << PD2) | (1 << PD3));
    
    // Configura PC0 y PC1 como entradas con pull-up
    DDRC &= ~((1 << PC0) | (1 << PC1));
    PORTC |= (1 << PC0) | (1 << PC1);
    
    TWI_Slave_Init(SLAVE_ADDRESS);
    
    // Habilita interrupci�n por cambio de pines en Port C (PCIE1, PCINT8 y PCINT9)
    PCICR |= (1 << PCIE1);
    PCMSK1 |= (1 << PCINT8) | (1 << PCINT9);
    
    sei();
    
    while (1) {
        // Todo se maneja en las ISR.
    }
    return 0;
}


ISR(TWI_vect) {
	//5 bits superiores del registro TWSR
	uint8_t status = TWSR & 0xF8;
	uint8_t recived_data;
	switch (status) {
		/*//se ha recibido el SLA+W  y se ha enviado ACK.
		case 0x60:
		case 0x68:
		TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE) | (1 << TWINT);
		break;*/
		//se ha recibido un byte de datos y se ha enviado ACK
		case 0x80:
		recived_data = TWDR;
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//Se recibe la condici�n de stop o un star repetido
		/*case 0xA0:
		TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE) | (1 << TWINT);
		break;*/
		//el maestro ha enviado SLA+R  y ha solicitado leer datos
		case 0xA8:
		TWDR = counter;  // Env�a el valor del contador
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//se ha transmitido un byte y se recibi� ACK del maestro
		/*case 0xB8:
		TWDR = counter;
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//e ha transmitido un byte y se recibi� NACK (transmite el �ltimo byte)
		case 0xC0:
		case 0xC8:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;*/
		//se reestablece TWCR
		default:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
	}
}