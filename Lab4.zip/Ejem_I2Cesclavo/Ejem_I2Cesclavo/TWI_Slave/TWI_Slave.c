#include "TWI_Slave.h"
#include <avr/interrupt.h>

extern volatile uint8_t counter;

void TWI_Slave_Init(uint8_t slave_address) {
	TWAR = (slave_address << 1);
	TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE)| (1 << TWINT);
	TWSR = 0x00;
}

