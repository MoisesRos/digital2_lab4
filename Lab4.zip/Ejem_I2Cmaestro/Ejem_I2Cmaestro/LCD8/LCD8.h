#ifndef LCD8_H_
#define LCD8_H_

#include <avr/io.h>
#include <util/delay.h>

// Prototipos de funciones
void initLCD8(void);
void LCDcomando(char a);
void LCDport(char a);
void LCDcaracter(char c);
void LCDcadena(char *a);
void LCDderecha(void);
void LCDizquierda(void);
void LCDcursor(char c, char f);

#endif
