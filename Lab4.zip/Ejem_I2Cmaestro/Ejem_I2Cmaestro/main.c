
#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "TWI_Master/TWI_Master.h"
#include "LCD8/LCD8.h"
#include <stdlib.h>

#define SLAVE1_ADDRESS 0x10
#define SLAVE2_ADDRESS 0x20

// Convierte un n�mero (0-15) a una cadena de dos d�gitos.
void intToStr(uint8_t num, char *str) {
    str[0] = '0' + (num / 10);
    str[1] = '0' + (num % 10);
    str[2] = '\0';
}

// Convierte un valor ADC (0-255) a una cadena que representa el voltaje en formato "x.xxV".
// Se usa Vref = 5V.
void adcToVoltageStr(uint8_t adc, char *str) {
    // Calcula milivoltios: (adc * 5000) / 255
    uint16_t mv = (adc * 5000UL) / 255;
    uint8_t volts = mv / 1000;          // Parte entera
    uint8_t dec = (mv % 1000) / 10;       // Dos decimales
    str[0] = '0' + volts;
    str[1] = '.';
    str[2] = '0' + (dec / 10);
    str[3] = '0' + (dec % 10);
    str[4] = 'V';
    str[5] = '\0';
}

int main(void) {
    char counterStr[5];
    char voltageStr[6];
    uint8_t slave1Value, slave2Value;
    uint8_t commSuccess = 0;
    
    // Configura PB4 como salida para el indicador de comunicaci�n.
    DDRB |= (1 << PB4);
    PORTB &= ~(1 << PB4);  // Inicialmente apagado.
    
    // Inicializa la LCD y da tiempo para la secuencia de arranque.
    initLCD8();
  //  _delay_ms(150);
    LCDcomando(0x01); // Limpia la pantalla.
    //_delay_ms(150);
    
    // Escribe encabezados en la LCD.
    LCDcursor(1,1);
    LCDcadena("Sen1: ");
    LCDcursor(1,2);
    LCDcadena("Sen2: ");
    
    // Inicializa el TWI en modo maestro a 100 kHz.
    TWI_Master_Init(100000);
    //_delay_ms(500);
    
    while (1) {
        //commSuccess = 1;  // Se asume �xito; se invalidar� si falla alguna comunicaci�n.
        
        // --- Lectura de Esclavo 1 (contador) ---
		TWI_Start();
		TWI_Write((SLAVE1_ADDRESS << 1) | 1);
		uint8_t rd = TWI_Read_NACK();
		TWI_Stop();
		
		TWI_Start();
		TWI_Write((SLAVE2_ADDRESS << 1) | 1);
		uint8_t rd2 = TWI_Read_NACK();
		TWI_Stop();
		
        /*if (TWI_Start((SLAVE1_ADDRESS << 1) | 0x01) == 0) {
            slave1Value = TWI_Read_NACK();
            TWI_Stop();
        } else {
            slave1Value = 0xFF;
            commSuccess = 0;
        }*/
        
        /*// --- Lectura de Esclavo 2 (ADC) ---
        if (TWI_Start((SLAVE2_ADDRESS << 1) | 0x01) == 0) {
            slave2Value = TWI_Read_NACK();
            TWI_Stop();
        } else {
            slave2Value = 0xFF;
            commSuccess = 0;
        }*/
        
        // Convertir valores a cadenas.
        //intToStr(rd, counterStr);
		itoa(rd,counterStr,10);
        adcToVoltageStr(rd2, voltageStr);
        
        // Actualiza la primera l�nea: "Sen1: <contador>"
        LCDcursor(7,1);
        LCDcadena("   ");  // Borra el valor anterior (3 espacios).
        LCDcursor(7,1);
        LCDcadena(counterStr);
        
        // Actualiza la segunda l�nea: "Sen2: <voltaje>"
        LCDcursor(7,2);
        LCDcadena("     ");  // Borra el valor anterior (5 espacios).
        LCDcursor(7,2);
        LCDcadena(voltageStr);
        
        // Indicador de comunicaci�n: si fue exitosa, enciende PB4.
       /* if (commSuccess) {
            PORTB |= (1 << PB4);
        } else {
            PORTB &= ~(1 << PB4);
        }
        
        //_delay_ms(500);*/
    }
    
    return 0;
}
