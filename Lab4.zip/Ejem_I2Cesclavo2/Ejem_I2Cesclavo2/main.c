

#include <avr/io.h>
#include <avr/interrupt.h>
#include "TWI_Slave2/TWI_Slave.h"

#define SLAVE_ADC_ADDRESS 0x20

volatile uint8_t adcValue = 0;

void ADC_Init(void) {
    // Configura ADMUX
    // - Left adjust result (ADLAR = 1) para obtener el resultado en ADCH (8 bits)
    // - Selecciona el canal ADC6 (MUX = 6); adem�s, usa AVcc como referencia (REFS0 = 1)
    ADMUX = (1 << ADLAR) | (1 << REFS0) | (6 & 0x0F);
    
    // Configura ADCSRA:
    // - Habilita el ADC (ADEN)
    // - Habilita la interrupci�n del ADC (ADIE)
    // - Prescaler = 128 para un reloj de ADC dentro del rango
    ADCSRA = (1 << ADEN) | (1 << ADIE) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
    
    // Inicia la primera conversi�n
    ADCSRA |= (1 << ADSC);
}

ISR(ADC_vect) {
    // Como el resultado est� left adjusted, se lee ADCH (8 bits)
    adcValue = ADCH;
    // Inicia la siguiente conversi�n
    ADCSRA |= (1 << ADSC);
}

int main(void) {
    ADC_Init();
    DDRB |= (1 << PB5);  // En main_slave1.c, antes de habilitar interrupciones.
    PORTB &= ~(1 << PB5);
    TWI_Slave_Init(SLAVE_ADC_ADDRESS);
    
    sei();
    
    while (1) {
        // Las conversiones ADC y la comunicaci�n I�C se manejan en las ISR.
    }
    return 0;
}

ISR(TWI_vect) {
	//5 bits superiores del registro TWSR
	uint8_t status = TWSR & 0xF8;
	uint8_t recived_data;
	switch (status) {
		/*//se ha recibido el SLA+W  y se ha enviado ACK.
		case 0x60:
		case 0x68:
		TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE) | (1 << TWINT);
		break;*/
		//se ha recibido un byte de datos y se ha enviado ACK
		case 0x80:
		recived_data = TWDR;
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//Se recibe la condici�n de stop o un star repetido
		/*case 0xA0:
		TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE) | (1 << TWINT);
		break;*/
		//el maestro ha enviado SLA+R  y ha solicitado leer datos
		case 0xA8:
		TWDR = adcValue;  // Env�a el valor del contador
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//se ha transmitido un byte y se recibi� ACK del maestro
		/*case 0xB8:
		TWDR = counter;
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		//e ha transmitido un byte y se recibi� NACK (transmite el �ltimo byte)
		case 0xC0:
		case 0xC8:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;*/
		//se reestablece TWCR
		default:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
	}
}